import setuptools


x = setuptools.find_packages()
print(x)